<?php
session_start();
include_once("config.php");


//current URL of the Page. cart_update.php redirects back to this URL
$current_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sản phẩm</title>
<meta name="format-detection" content="telephone=no">
  <meta name="viewport"
    content="width=device-width, height=device-height, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta charset="utf-8">
  <link rel="icon" href="images/favicon.ico" type="image/x-icon">
  <!-- Stylesheets-->
  <link rel="stylesheet" type="text/css"
    href="//fonts.googleapis.com/css?family=Fira+Sans:300,600,800,800i%7COpen+Sans:300,400,400i">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/fonts.css">
  <link href="style/style.css" rel="stylesheet" type="text/css">
  <style>
    .ie-panel {
      display: none;
      background: #212121;
      padding: 10px 0;
      box-shadow: 3px 3px 5px 0 rgba(0, 0, 0, .3);
      clear: both;
      text-align: center;
      position: relative;
      z-index: 1;
    }

    html.ie-10 .ie-panel,
    html.lt-ie-10 .ie-panel {
      display: block;
    }
  </style>
</head>
<body>
   <!-- Page-->
  <div class="page"><a class="banner banner-top"
      href="http://3dbuilder.vn/product.php" target="_blank"><img
        src="images/intense_02.jpg" alt="" height="0" /></a>
    <header class="page-header">
      <!-- RD Navbar-->
      <div class="rd-navbar-wrap">
        <nav class="rd-navbar rd-navbar_transparent rd-navbar_boxed" data-layout="rd-navbar-fixed"
          data-sm-layout="rd-navbar-fixed" data-sm-device-layout="rd-navbar-fixed" data-md-layout="rd-navbar-fixed"
          data-md-device-layout="rd-navbar-fixed" data-lg-device-layout="rd-navbar-fixed"
          data-lg-layout="rd-navbar-static" data-xl-device-layout="rd-navbar-static" data-xl-layout="rd-navbar-static"
          data-xxl-device-layout="rd-navbar-static" data-xxl-layout="rd-navbar-static" data-stick-up-clone="false"
          data-sm-stick-up="true" data-md-stick-up="true" data-lg-stick-up="true" data-md-stick-up-offset="115px"
          data-lg-stick-up-offset="35px" data-body-class="rd-navbar-absolute">
          <!-- RD Navbar Top Panel-->
          <div class="rd-navbar-top-panel">
            <div class="rd-navbar-top-panel__main">
              <div class="rd-navbar-top-panel__toggle rd-navbar-fixed__element-1 rd-navbar-static--hidden"
                data-rd-navbar-toggle=".rd-navbar-top-panel__main"><span></span></div>
              <div class="rd-navbar-top-panel__content">
                <div class="rd-navbar-top-panel__left">
                  <ul class="rd-navbar-items-list">
                    <li>
                      <div class="unit flex-row align-items-center unit-spacing-xs">
                        <div class="unit__left"><span class="icon icon-sm icon-primary linear-icon-map-marker"></span>
                        </div>
                        <div class="unit__body">
                          <p><a href="#">Địa chỉ: 453 Lê Văn Sỹ - P12 - Q3 - Hồ Chí Minh</a></p>
                        </div>
                      </div>
                    </li>
                    <li>
                      <div class="unit flex-row align-items-center unit-spacing-xs">
                        <div class="unit__left"><span class="icon icon-sm icon-primary linear-icon-telephone"></span>
                        </div>
                        <div class="unit__body">
                          <ul class="list-semicolon">
                            <li><a href="tel:#">(+84) 36 86 36 113</a></li>
                          </ul>
                        </div>
                        <div>
                            <ul style="margin-left:50px" class="rd-navbar-nav">
                              <li ><a href="index.html">Trang chủ</a>
                              </li>
                              <li class="active"><a href="product.php">Sản phẩm</a>
                              </li>
                              <li><a href="view_cart.php">Giỏ hàng</a>
                              </li>
                              <li><a href="about.html">Về chúng tôi</a>
                              </li>
                              <li><a href="contacts.html">Liên hệ</a>
                              </li>
                            </ul>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
                <div class="rd-navbar-top-panel__right">
                  <ul class="list-inline-xxs">
                    <li><a class="icon icon-xxs icon-gray-darker fa fa-facebook" href="#"></a></li>
                    <li><a class="icon icon-xxs icon-gray-darker fa fa-twitter" href="#"></a></li>
                    <li><a class="icon icon-xxs icon-gray-darker fa fa-google-plus" href="#"></a></li>
                    <li><a class="icon icon-xxs icon-gray-darker fa fa-youtube" href="#"></a></li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

        </nav>
      </div>
    </header> 
 
<!-- View Cart Box Start -->
<?php
if(isset($_SESSION["cart_products"]) && count($_SESSION["cart_products"])>0)
{
	echo '<div class="cart-view-table-front" id="view-cart">';
	echo '<h6>Giỏ hàng</h6>';
	echo '<form method="post" action="cart_update.php">';
	echo '<table width="100%"  cellpadding="6" cellspacing="0">';
	echo '<tbody>';

	$total =0;
	$b = 0;
	foreach ($_SESSION["cart_products"] as $cart_itm)
	{
		$product_name = $cart_itm["product_name"];
		$product_qty = $cart_itm["product_qty"];
		$product_price = $cart_itm["product_price"];
		$product_code = $cart_itm["product_code"];
		$product_color = $cart_itm["product_color"];
		$bg_color = ($b++%2==1) ? 'odd' : 'even'; //zebra stripe
		echo '<tr class="'.$bg_color.'">';
		echo '<td>Qty <input type="text" size="2" maxlength="2" name="product_qty['.$product_code.']" value="'.$product_qty.'" /></td>';
		echo '<td>'.$product_name.'</td>';
		echo '<td><input type="checkbox" name="remove_code[]" value="'.$product_code.'" /> Remove</td>';
		echo '</tr>';
		$subtotal = ($product_price * $product_qty);
		$total = ($total + $subtotal);
	}
	echo '<td colspan="4">';
	echo '<button type="submit">Update</button><a href="view_cart.php" class="button">Checkout</a>';
	echo '</td>';
	echo '</tbody>';
	echo '</table>';
	
	$current_url = urlencode($url="http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);
	echo '<input type="hidden" name="return_url" value="'.$current_url.'" />';
	echo '</form>';
	echo '</div>';

}
?>
<!-- View Cart Box End -->


<!-- Products List Start -->
<?php
$results = $mysqli->query("SELECT product_code, product_name, product_desc, product_img_name, price FROM products ORDER BY id ASC");
if($results){ 
$products_item = '<ul class="products">';
//fetch results set as object and output HTML
while($obj = $results->fetch_object())
{
$products_item .= <<<EOT
	<li class="product">
	<form method="post" action="cart_update.php">
	<div class="product-content"><h6>{$obj->product_name}</h6>
	<div class="product-thumb"><img src="images/{$obj->product_img_name}"></div>
	<div class="product-desc">{$obj->product_desc}</div>
	<div class="product-info">
	Price {$currency}{$obj->price} 
	
	<fieldset>
	
	<label>
		<span>Color</span>
		<select name="product_color">
		<option value="Black">Black</option>
		<option value="Silver">Silver</option>
		</select>
	</label>
	
	<label>
		<span>Quantity</span>
		<input type="text" size="2" maxlength="2" name="product_qty" value="1" />
	</label>
	
	</fieldset>
	<input type="hidden" name="product_code" value="{$obj->product_code}" />
	<input type="hidden" name="type" value="add" />
	<input type="hidden" name="return_url" value="{$current_url}" />
	<div align="center"><button type="submit" class="add_to_cart">Add</button></div>
	</div></div>
	</form>
	</li>
EOT;
}
$products_item .= '</ul>';
echo $products_item;
}
?>    
<!-- Products List End -->
</div>
<!-- Javascript-->
<script src="js/core.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>
